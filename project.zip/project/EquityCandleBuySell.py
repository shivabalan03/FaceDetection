from kite_trade import *
import threading
import time
import datetime
import winsound
import os
import json
from flask import *
app = Flask(__name__)

# # Second way is provide 'enctoken' manually from 'kite.zerodha.com' website
# # Than you can use login window of 'kite.zerodha.com' website Just don't logout from that window
# currStk = next((item for item in stocks if item['stock'] == stockName), None)
enctoken = "aLmJQsbhBPOtIthcqgXPQYcNObyfa+WCo9RNx54rJW4eGZEEGadxlyQ/IHTay4jeKeMVo0j7XZQNKPD1c7O7kVVGZIhgp23aq6MQNCJ8WLyX4Ci5XSbadQ=="
kite = KiteApp(enctoken=enctoken)

stock = ""
# Set Every Day
obj = {
    "_currentTime": datetime.datetime.now(),
    "_watchStock": "SCHNEIDER",
    "_exchange": "NSE",
    "_inBucket": False,
    "_quantity": 0,
    "_orderPlanQuantity": 1,
    "_pTrend": True, # Set what is current trend for _watchStock
    "_pTrendHistory": [], # Set what is current trend for _watchStock
    "_cTrend": False,
    "_CTrendSeq": [],
    "_fund": 0,
    "_avgPrice": 0,
    "_openPrice": 0,
    "_message": "",
    "_transactionType": "",
    "_st1": {},
    "_st2": {},
    "_st3": {},
    "_ohlc": {
        "open": 0,
        "high": 0,
        "low": 0,
        "close": 0,
    }
}

class eq:
    def mostFrequent(arr, n):
        maxcount = 0
        element_having_max_freq = 0
        for i in range(0, n):
            count = 0
            for j in range(0, n):
                if(arr[i] == arr[j]):
                    count += 1
            if(count > maxcount):
                maxcount = count
                element_having_max_freq = arr[i]

    def checkAllFlagSame(arr, n):
        if arr[0] == True and arr[1] == True and arr[2] == True:
            return True
        elif arr[0] == False and arr[1] == False and arr[2] == False:
            return False
        else:
            return obj["_cTrend"]
        
    def ohlc(self, data):
        try:
            return {
                "open": data["open"],
                "high": data["high"],
                "low": data["low"],
                "close": data["close"],
            }
        except Exception:
            obj["_message"] = "Error"
    
    def currentPostions(self):        
        positions = kite.positions()  
        if positions is not None:       
            currStk = next((item for item in positions['day'] if item['tradingsymbol'] == obj["_watchStock"] and item['exchange'] == 'NSE' and item['product'] == 'MIS'), None)
            if currStk is not None:
                obj["_quantity"] = currStk['quantity'] 
    def currentFund(self):                   
        obj["_fund"] = kite.margins().get('equity').get('available').get("live_balance") 
    def setInstrumentToken(self):  
        instrument_token = kite.instruments(obj["_exchange"], obj["_watchStock"])         
        token = instrument_token[0]["instrument_token"]      
        from_datetime = datetime.datetime.now() - datetime.timedelta(days=5)     # From last & days
        to_datetime = datetime.datetime.now()             
        data = kite.historical_data(token, from_datetime, to_datetime, "5minute", continuous=False, oi=False)                                          
        obj["_avgPrice"] = (data["open"].iloc[-1] + data["high"].iloc[-1] + data["low"].iloc[-1] + data["close"].iloc[-1]) / 4 
        obj["_openPrice"] = data["open"].iloc[-1]
        obj["_ohlc"]["open"] = data["open"].iloc[-1]                        
        obj["_ohlc"]["high"] = data["high"].iloc[-1]                        
        obj["_ohlc"]["low"] = data["low"].iloc[-1]                        
        obj["_ohlc"]["close"] = data["close"].iloc[-1]  
        secondsT = kite.Supertrend(data, 10, 3)          
        obj["_cTrend"] = secondsT["Supertrend"].iloc[-1]  

    def isCurrentTimeDivisableBy15(self):
        myobj = datetime.datetime.now()             
        if(myobj.minute == 0 or myobj.minute == 15 or myobj.minute == 30 or myobj.minute == 45):
            return True
        else:
            return False
    def placeOrder(self, transactionType):
        order = kite.place_order(variety=kite.VARIETY_REGULAR,
                            exchange=kite.EXCHANGE_NSE,
                            tradingsymbol=obj["_watchStock"],
                            transaction_type=transactionType,#kite.TRANSACTION_TYPE_BUY,
                            quantity=obj["_orderPlanQuantity"],
                            product=kite.PRODUCT_MIS,
                            order_type=kite.ORDER_TYPE_MARKET,
                            price=None,
                            validity=None,
                            disclosed_quantity=None,
                            trigger_price=None,
                            squareoff=None, 
                            stoploss=None,
                            trailing_stoploss=None,
                            tag = "SuperTrendAlgo"
                            )
        self.notification()
        return order
    def notification(self):
        duration = 1000  # milliseconds
        freq = 440  # Hz
        winsound.Beep(freq, duration)
    def setAllData(self):
        self.currentPostions()
        self.setInstrumentToken()
        self.currentFund()                          

@app.route('/')
def index():
    return render_template('Equity.html')

@app.route('/getData', methods=['POST'])
def mainMethod():    
    qtc_data = request.get_json()    
    e = eq()
    try:
        obj["_watchStock"] = qtc_data["stock"]
        now = datetime.datetime.today() 
        obj["_currentTime"] = now.strftime("%Y-%m-%d %I:%M:%S %p")                         
        e.setAllData() 
        obj["_message"] = "No Message"
        print(now.strftime("%Y-%m-%d %I:%M:%S %p"))

        if (len(obj["_pTrendHistory"]) < 3):
            obj["_pTrendHistory"].append(obj["_cTrend"])   
            
        if (len(obj["_pTrendHistory"]) == 3):
            obj["_pTrendHistory"].pop(0)
            obj["_pTrendHistory"].append(obj["_cTrend"])
            if obj["_pTrendHistory"][0] != obj["_cTrend"] and obj["_pTrendHistory"][1] != obj["_cTrend"] and obj["_pTrendHistory"][2] != obj["_cTrend"]:                
                if obj["_quantity"] > 0:
                    # o = e.placeOrder(kite.TRANSACTION_TYPE_SELL)
                    # print(o)
                    obj["_message"] = "Sell Order Placed"
                    obj["_transactionType"] = "SELL"
                    print(obj["_message"])
                if obj["_quantity"] < 0:
                    # o = e.placeOrder(kite.TRANSACTION_TYPE_BUY)
                    # print(o)
                    obj["_message"] = "Buy Order Placed"
                    obj["_transactionType"] = "BUY"
                    print(obj["_message"])

                # if obj["_inBucket"]:                                    
                #     if obj["_quantity"] > 0:
                #         # o = e.placeOrder(kite.TRANSACTION_TYPE_SELL)
                #         # print(o)
                #         obj["_message"] = "Sell Order Placed"
                #         obj["_transactionType"] = "SELL"
                #         print(obj["_message"])
                #     elif obj["_quantity"] < 0:
                #         # o = e.placeOrder(kite.TRANSACTION_TYPE_BUY)
                #         # print(o)
                #         obj["_message"] = "Buy Order Placed"
                #         obj["_transactionType"] = "BUY"
                #         print(obj["_message"])
                #     obj["_inBucket"] = False
                #     obj["_pTrend"] = obj["_cTrend"]
                # else:
                #     if obj["_cTrend"]:
                #         if obj["_quantity"] > 0:
                #             print("Already entered with BUY Order")
                #         elif obj["_quantity"] <= 0:
                #             # o = e.placeOrder(kite.TRANSACTION_TYPE_BUY)
                #             # print(o)
                #             obj["_message"] = "Buy Order Placed"
                #             obj["_transactionType"] = "BUY"
                #             obj["_inBucket"] = True                            
                #             print(obj["_message"])
                #     else:
                #         if obj["_quantity"] <= 0:
                #             # o = e.placeOrder(kite.TRANSACTION_TYPE_SELL)
                #             # print(o)
                #             obj["_message"] = "Sell Order Placed"
                #             obj["_transactionType"] = "SELL"
                #             obj["_inBucket"] = True   
                #             print(obj["_message"])                         
                #         else:
                #             print("Already entered with SELL Order") 
            else:
                print("No Trend Change")
    except Exception:
        # e.notification()        
        obj["_message"] = "Error"
    finally:        
        print("Press Enter to continue ...")
        print(obj)
        return json.dumps(obj, default=str) # json.dumps({"data":obj})

if __name__ == '__main__':    
    app.run(debug=True, port=5001)