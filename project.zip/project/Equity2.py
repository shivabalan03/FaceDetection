from kite_trade import *
import threading
import time
import datetime
import winsound
import os
import json
from flask import *
app = Flask(__name__)

# # Second way is provide 'enctoken' manually from 'kite.zerodha.com' website
# # Than you can use login window of 'kite.zerodha.com' website Just don't logout from that window
# currStk = next((item for item in stocks if item['stock'] == stockName), None)
enctoken = "pk6UjdognPCSE9Vx6Nc6XYCwNRtqsNDwskf1DRp78xnnDYxDyrOVwo5tF8/XRRSMGa1GiM387ULXIqZo8OjemFBN1j45HKSBV8O5lFf+QXIXHTG1g7mZMw=="
kite = KiteApp(enctoken=enctoken)
kiteNew = ZerodhaKiteTrade()

data2 = {
    "StopExecution": False,
    "OverallUnrealised": 0,
    "OverallStopLoss": -200,
    "stock": {
        "stockName": "LLOYDSME", # Need to Set
        "exchange": "NSE",
        "instrumentToken": "",
    },
    "common": {
        "dateTime": datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S %p"),
        "message": "",
        "transactionType": "",
        "availableFund": 0,
        "availableQuantity": 0,
        "plannedQuantity": 10, # Need to Set
    },
    "trendInfo": {
        "o": 0,
        "h": 0,
        "l": 0,
        "c": 0,
        "a": 0,
        "recentT": [],
        "previousT": "",
        "currentT": "",
        "purchasePrice": 0,
    }
}

class Equity:
    def placeOrder(self, transactionType, additionalQty=0):
        if data2["common"]["availableQuantity"] == 0 or data2["common"]["availableQuantity"] == -(data2["common"]["plannedQuantity"]) or data2["common"]["availableQuantity"] == (data2["common"]["plannedQuantity"]):
            order = kite.place_order(variety=kite.VARIETY_REGULAR,
                                exchange=kite.EXCHANGE_NSE,
                                tradingsymbol=data2["stock"]["stockName"],
                                transaction_type=transactionType,#kite.TRANSACTION_TYPE_BUY,
                                quantity=(data2["common"]["plannedQuantity"] + additionalQty),
                                product=kite.PRODUCT_MIS,
                                order_type=kite.ORDER_TYPE_MARKET,
                                price=None,
                                validity=None,
                                disclosed_quantity=None,
                                trigger_price=None,
                                squareoff=None, 
                                stoploss=None,
                                trailing_stoploss=None,
                                tag = "SuperTrendAlgo"
                                )            
            self.currentPostions()
            return order
        else:
            data2["common"]["message"] = "Quantity limit has been Reached Please check"
            return None
    def currentFund(self):                   
        data2["common"]["availableFund"] = kite.margins().get('equity').get('available').get("live_balance") 
    def currentPostions(self):        
        positions = kite.positions()  
        if positions is not None:       
            currStk = next((item for item in positions['day'] if item['tradingsymbol'] == data2["stock"]["stockName"] and item['exchange'] == data2["stock"]["exchange"] and item['product'] == 'MIS'), None)
            if currStk is not None:
                data2["common"]["availableQuantity"] = currStk['quantity'] 
                data2["OverallUnrealised"] = currStk['unrealised'] 
    def setInstrumentToken(self):  
        instrument_token = kite.instruments(data2["stock"]["exchange"], data2["stock"]["stockName"])         
        data2["stock"]["instrumentToken"] = instrument_token[0]["instrument_token"]      
        from_datetime = datetime.datetime.now() - datetime.timedelta(days=5)     # From last & days
        to_datetime = datetime.datetime.now()             
        history = kite.historical_data(data2["stock"]["instrumentToken"], from_datetime, to_datetime, "5minute", continuous=False, oi=False)                                          
        data2["trendInfo"]["a"] = (history["open"].iloc[-1] + history["high"].iloc[-1] + history["low"].iloc[-1] + history["close"].iloc[-1]) / 4         
        data2["trendInfo"]["o"] = history["open"].iloc[-1]                        
        data2["trendInfo"]["h"] = history["high"].iloc[-1] 
        data2["trendInfo"]["l"] = history["low"].iloc[-1]                
        data2["trendInfo"]["c"] = history["close"].iloc[-1]  
        # trendInfo = kite.Supertrend(history, 10, 3)  
        trendInfo = kiteNew.SuperTrend(history, 10, 3)
        data2["trendInfo"]["currentT"] = trendInfo["STX"].iloc[-1] 
        if len(data2["trendInfo"]["recentT"]) >= 3:
            data2["trendInfo"]["recentT"].pop(0)
            data2["trendInfo"]["recentT"].append(data2["trendInfo"]["currentT"])
        else:
            data2["trendInfo"]["recentT"].append(data2["trendInfo"]["currentT"])
    def setAllData(self):
        self.currentFund() 
        self.currentPostions()
        self.setInstrumentToken()
    

@app.route('/')
def index():
    return render_template('Equity2.html')

@app.route('/getDataEQ2', methods=['POST'])
def mainMethod():    
    # qtc_data = request.get_json()    
    equity = Equity()
    try:  
        if(data2["StopExecution"] == False):                     
            equity.setAllData() 
            data2["common"]["dateTime"] = datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S %p")
            data2["common"]["message"] = ""
            data2["common"]["transactionType"] = ""
            
            if (len(data2["trendInfo"]["recentT"]) < 3):
                data2["common"]["message"] = "Current Trend length < 3"
            else:
                if (len(data2["trendInfo"]["recentT"]) == 3):
                    print('unrealised : ' + str(data2["OverallUnrealised"]))
                    if(data2["common"]["availableQuantity"] != 0):
                        if (float(data2['OverallUnrealised']) < float(data2['OverallStopLoss'])):
                            if data2["common"]["plannedQuantity"] == -(data2["common"]["availableQuantity"]):
                                o = equity.placeOrder(kite.TRANSACTION_TYPE_BUY)                                
                                data2["trendInfo"]["previousT"] = data2["trendInfo"]["currentT"]
                                data2["common"]["message"] = "Stopped Loss Order Executed"
                                data2["common"]["transactionType"] = "BUY"
                            elif data2["common"]["plannedQuantity"] == data2["common"]["availableQuantity"]:
                                o = equity.placeOrder(kite.TRANSACTION_TYPE_SELL)                                
                                data2["trendInfo"]["previousT"] = data2["trendInfo"]["currentT"]
                                data2["common"]["message"] = "Stopped Loss Order Executed"
                                data2["common"]["transactionType"] = "SELL"
                                # data2["trendInfo"]["purchasePrice"] = o["average_price"]
                            data2["StopExecution"] = True                     

                    if (((data2["trendInfo"]["recentT"][0]  == data2["trendInfo"]["recentT"][1]  == data2["trendInfo"]["recentT"][2]) and 
                        (data2["trendInfo"]["previousT"] != data2["trendInfo"]["currentT"])) or data2["trendInfo"]["previousT"] == ""):  
                            if data2["common"]["availableQuantity"] == 0:
                                if data2["trendInfo"]["currentT"]:                                
                                    o = equity.placeOrder(kite.TRANSACTION_TYPE_BUY)
                                    print(o)                                    
                                    data2["trendInfo"]["previousT"] = data2["trendInfo"]["currentT"]
                                    data2["common"]["message"] = "Buy Order Placed"
                                    data2["common"]["transactionType"] = "BUY"
                                    # data2["trendInfo"]["purchasePrice"] = o["average_price"]
                                else:
                                    o = equity.placeOrder(kite.TRANSACTION_TYPE_SELL)
                                    print(o)                                    
                                    data2["trendInfo"]["previousT"] = data2["trendInfo"]["currentT"]
                                    data2["common"]["message"] = "SELL order placed"
                                    data2["common"]["transactionType"] = "SELL"
                                    # data2["trendInfo"]["purchasePrice"] = o["average_price"]
                            else:
                                if data2["common"]["availableQuantity"] == -(data2["common"]["plannedQuantity"]):
                                    if data2["trendInfo"]["recentT"][0] and data2["trendInfo"]["recentT"][1] and data2["trendInfo"]["recentT"][2]:                                
                                        o = equity.placeOrder(kite.TRANSACTION_TYPE_BUY)
                                        print(o)                                        
                                        data2["trendInfo"]["previousT"] = data2["trendInfo"]["currentT"]
                                        data2["common"]["message"] = "Buy Order Placed"
                                        data2["common"]["transactionType"] = "BUY"
                                        # data2["trendInfo"]["purchasePrice"] = o["average_price"]
                                elif data2["common"]["availableQuantity"] == data2["common"]["plannedQuantity"]:
                                    if not data2["trendInfo"]["recentT"][0] and not data2["trendInfo"]["recentT"][1] and not data2["trendInfo"]["recentT"][2]:
                                        o = equity.placeOrder(kite.TRANSACTION_TYPE_SELL)
                                        print(o)                                        
                                        data2["common"]["message"] = "SELL order placed"
                                        data2["common"]["transactionType"] = "SELL"
                                        # data2["trendInfo"]["purchasePrice"] = o["average_price"]
                    else:
                        data2["common"]["message"] = "No Trend Reversal"
                        print("No Trend Change")
        else:            
            data2["common"]["message"] = "SELL order placed"
    except Exception as inst:
        print(type(inst))   
        print(inst.args) 
    finally:                
        print(data2)
        print('\n')
        return json.dumps(data2, default=str)

if __name__ == '__main__':    
    app.run(debug=True, port=5002)