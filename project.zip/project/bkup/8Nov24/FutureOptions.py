from kite_trade import *
import threading
import time
import datetime
import winsound
from pathlib import Path


# # Second way is provide 'enctoken' manually from 'kite.zerodha.com' website
# # Than you can use login window of 'kite.zerodha.com' website Just don't logout from that window
enctoken = "FUgflf6Mnw4CWRGlySfaEgag02mJj53BcKW7tglnlmO4mmc6viREEJV8WQUQueTjdiZ5DlOEAaW2AhT7GVEIEeYGEPbXIz9hU4SGlE1ORn2EvD46U2VW8w=="
kite = KiteApp(enctoken=enctoken)

# Set Every Day
_timeFrame = "5minute"
_optionContractDate = "NIFTY24O03"
_lotQty = 25 
_EquityExchange = "NSE"
_FandOExchange = "NFO"
_nifty50Symbol = "NIFTY 50"

# Variables and Information
_currentFund = 0
_isPositionExists = True
_orderHistoryContract = ""
_currentContractInfo = {
    "calculatedContractName": "",
    "positionContractName": "",
    "stopLoss": 0,
    "token": "",
    "avgPrice": 0,
    "positionExists": True,
    "contractPremium": 0,
    "requiredMargin": 0,
    "availablequantity": 0
}
_nifty50Info = {
    "token": "",
    "avgPrice": 0,
    "currentTrend": False,
    "strikePrice": 0,
    "availableFund": 0
}

class FandO:
    def orderHistorylog(self, type, contractName):
        if(type == "BUY"):  
            with open("OrderHistory.txt", "a") as myfile1:  
                myfile1.write(contractName)        
                myfile1.close()
        else:
             open('OrderHistory.txt', 'w').close()

    def writelog(self, stockName, trend, avgPrice, now):
         with open("report_01Oct.txt", "a") as myfile:            
            orderType = "BUY" if trend else "SELL"
            myfile.write("\n")
            myfile.write(now.strftime("%Y-%m-%d %I:%M %p") + "\t" + str(stockName) + "\t" + str(orderType) +"\t" + str(avgPrice))
            myfile.close()

    def setOrderHistoryContractName(self):
        with open("OrderHistory.txt", "r") as myfile:
            _orderHistoryContract = myfile.read()
            myfile.close()
 
    def fundInfo(self):
        _nifty50Info["availableFund"] = kite.margins().get('equity').get('available').get("live_balance")        
       
   
    def setNifty50InstrumentToken(self):
        instrument_token = kite.instruments(_EquityExchange, _nifty50Symbol)
        _nifty50Info["token"] = instrument_token[0]["instrument_token"]
        _currentContractInfo["symbol"] = _nifty50Symbol
 
    def setContractInstrumentToken(self):
        instrument_token = kite.instruments(_FandOExchange, _currentContractInfo["calculatedContractName"])
        _currentContractInfo["token"] = instrument_token[0]["instrument_token"]
 
    def setNifty50Info(self):
        from_datetime = datetime.datetime.now() - datetime.timedelta(days=1)
        to_datetime = datetime.datetime.now()    
        Hdata = kite.historical_data(_nifty50Info["token"], from_datetime, to_datetime, _timeFrame, continuous=False, oi=False)
        _nifty50Info["avgPrice"] = (Hdata["open"].iloc[-1] + Hdata["high"].iloc[-1] + Hdata["low"].iloc[-1] + Hdata["close"].iloc[-1]) / 4        
        sTrend = kite.Supertrend(Hdata, 1, 2)
        _nifty50Info["currentTrend"] = sTrend["Supertrend"].iloc[-1]
        _nifty50Info["strikePrice"] = round(_nifty50Info["avgPrice"] / 50) * 50
        _currentContractInfo["calculatedContractName"] = str(_optionContractDate) + str(_nifty50Info["strikePrice"]) + "CE"
   
    def myPositionsQuantity(self):        
        positions = kite.positions()    
        isExists = 0    
        for position in positions["net"]:                      
            if position["exchange"] == "NFO" and position["quantity"] > 0:
                _currentContractInfo["positionContractName"] = position["tradingsymbol"]
                return position["quantity"]                      
        return isExists
   
    def setContractInfo(self):        
        from_datetime = datetime.datetime.now() - datetime.timedelta(days=1)
        to_datetime = datetime.datetime.now()        
        Hdata = kite.historical_data(_currentContractInfo["token"], from_datetime, to_datetime, _timeFrame, continuous=False, oi=False)                
        sTrend = kite.Supertrend(Hdata, 1, 2)
        _currentContractInfo["stopLoss"] = sTrend["Final Lowerband"].iloc[-1]
        _currentContractInfo["avgPrice"] = (sTrend["open"].iloc[-1] + sTrend["high"].iloc[-1] + sTrend["low"].iloc[-1] + sTrend["close"].iloc[-1]) / 4        
        _currentContractInfo["contractPremium"] = round(_currentContractInfo["avgPrice"])
        _currentContractInfo["availablequantity"] = self.myPositionsQuantity()
        _currentContractInfo["requiredMargin"] = _currentContractInfo["avgPrice"] * _lotQty
        _currentContractInfo["positionExists"] = True if (_currentContractInfo["availablequantity"] > 0) else False
   
    def setNifty50andContractInfo(self):
        self.fundInfo()
        self.setNifty50InstrumentToken()
        self.setNifty50Info()

        self.setOrderHistoryContractName()
        self.setContractInstrumentToken()
        self.setContractInfo()

def mainMethod():
    if __name__ == '__main__':    
        while True:
            now = datetime.datetime.today()
            # duration = 1000  # milliseconds
            # freq = 440  # Hz
            # winsound.Beep(freq, duration)
            print("Started Main Job " + str(now))
            fo = FandO()
            fo.setNifty50andContractInfo()
            print("Nifty50 Info: ", _nifty50Info)
            print("Contract Info: ", _currentContractInfo)
            if _nifty50Info["currentTrend"]:            
                if not _currentContractInfo["positionExists"]:
                    if(_nifty50Info["availableFund"] > _currentContractInfo["requiredMargin"]):
                        # order = kite.place_order(variety=kite.VARIETY_REGULAR,
                        #         exchange=kite.EXCHANGE_NFO,
                        #         tradingsymbol=_currentContractInfo["calculatedContractName"],
                        #         transaction_type=kite.TRANSACTION_TYPE_BUY,
                        #         quantity=_lotQty,
                        #         product=kite.PRODUCT_NRML,
                        #         order_type=kite.ORDER_TYPE_MARKET,
                        #         price=None,
                        #         validity=None,
                        #         disclosed_quantity=None,
                        #         trigger_price=None,
                        #         squareoff=None, 
                        #         stoploss=None,
                        #         trailing_stoploss=None,
                        #         tag = "SuperTrendAlgo"
                        # )
                        print("CE Buy Order Sent to Exchange..") 
                        if order["status"] == "success":
                            fo.orderHistorylog("BUY", _currentContractInfo["calculatedContractName"])
                            print("Buy Completed Successfully..! \n Order Id :" + str(order["data"]["order_id"]) + " Contract Name:  " + str(_currentContractInfo["calculatedContractName"]))
                        else:
                            print("Order failed : " + order)
                        fo.writelog(_currentContractInfo["calculatedContractName"], "BUY", _currentContractInfo["contractPremium"], now)
                    else:
                        print("Not Enough Balance")
                else:
                    print("Position Already Exists : " + str(_currentContractInfo["calculatedContractName"]) + " : " + str(_currentContractInfo["availablequantity"]))
            else:
                if _currentContractInfo["positionExists"]:
                    if _currentContractInfo["positionContractName"] == _orderHistoryContract:
                        if _currentContractInfo["positionContractName"] != "":
                            # order = kite.place_order(variety=kite.VARIETY_REGULAR,
                            #             exchange=kite.EXCHANGE_NFO,
                            #             tradingsymbol=_currentContractInfo["positionContractName"],
                            #             transaction_type=kite.TRANSACTION_TYPE_SELL,
                            #             quantity=_currentContractInfo["availablequantity"],
                            #             product=kite.PRODUCT_NRML,
                            #             order_type=kite.ORDER_TYPE_MARKET,
                            #             price=None,
                            #             validity=None,
                            #             disclosed_quantity=None,
                            #             trigger_price=None,
                            #             squareoff=None, 
                            #             stoploss=None,
                            #             trailing_stoploss=None,
                            #             tag = "SuperTrendAlgo"
                            # )
                            print("CE EXIT Order Sent to Exchange..") 
                            if order["status"] == "success":
                                fo.orderHistorylog("SELL", "")
                                print("EXIT Completed Successfully..! \n Order Id :" + str(order["data"]["order_id"]) + " Contract Name:  " + str(_currentContractInfo["calculatedContractName"] + " Quantity: " + str(_currentContractInfo["availablequantity"])))
                            else:
                                print("Order failed : " + order)
                            fo.writelog(_currentContractInfo["positionContractName"], "SELL", _currentContractInfo["contractPremium"], now)
                    else:
                        print("Position Not Entered by Algo : " + str(_currentContractInfo["positionContractName"]))
                else:
                    print("Position does not exists")

            print("---------------------------------------------------------------------------------------------------------------\n\n")
            time.sleep(60) # 60=1min 120=2min 300=5min 600=10min 900=15min 1800=30min 3600=1hr 7200=2hr 14400=4hr 28800=8hr 43200=12hr 86400=1day

mainMethod()

# i = kite.instruments("NSE", "NIFTY 50")
# from_datetime = datetime.datetime.now() - datetime.timedelta(days=1)     # From last & days
# to_datetime = datetime.datetime.now()    
# data = kite.historical_data(i,from_datetime, to_datetime, "5minute", continuous=False, oi=False)
# print(kite.Supertrend(data, 1,2))

# Step 1: 
#Loop Every 5 Minutes
    # InstrumentToken then HistoryData then SuperTrend
    # If Previous Trend Value != Current Trend Value
        # If Previous Trend Value == True and Current Trend Value == False            
            # Prepare OptionContract Instrument eg (NIFTY24OCT25900CE)
            # Check available postion qty and Exit Order with available qty
        # Else if Previous Trend Value == false and Current Trend Value == true
            # Calculate Avg and nifty 50 Find nearest value by 50 and Prepare OptionContract Instrument eg (NIFTY24OCT25900CE)
            # Get Live balance
            # check margin by given position qty
            # if(enough balance) then Buy