# Equity
# index = 1
# prepareData = []
# timeframe = "15minute"
# exchange = "NSE"
# watchList = ["BOSCHLTD", "PRICOLLTD", "COALINDIA", "CYIENT"]
# if __name__ == '__main__':
#     while True:
#         now = datetime.datetime.today()
#         print(str(index) + str(now))
#         for stockName in watchList:
#             eq = Equity()            
#             if index == 1: 
#                 iToken = eq.getInstrumentToken(exchange, stockName)
#                 cTrend = eq.getCurrentTrend(timeframe, iToken)
#                 prepareData.append({"stock": stockName, "token": iToken, "trend": str(cTrend), "boughtPrice": 0})                        
#             else:                
#                 currStk = next((item for item in prepareData if item['stock'] == stockName), None)                
#                 if currStk != None:
#                     iToken = eq.getInstrumentToken(exchange, stockName)
#                     cTrend = eq.getCurrentTrend(timeframe, iToken)
#                     previoustrend = currStk.get('trend')
#                     print('stockName :' + stockName + ' Previous Trend :' + previoustrend + ' Current Trend :' + str(cTrend) + " " + (("Trend Changed") if (str(previoustrend) != str(cTrend)) else ("Trend Not Changed")))                    
#                     if str(previoustrend) != str(cTrend):
#                         avgPrice = eq.getCurrentAvgPrice(timeframe, iToken) 
#                         # eq.writelog(stockName, cTrend, avgPrice)
#                         if cTrend and not previoustrend: #(Current Trend = T and Previous Trend = F)
#                             #BUY
#                             for p in prepareData:
#                                 if p['stock'] == stockName:
#                                     p['boughtPrice'] = avgPrice
#                                     eq.writelog(stockName, cTrend, avgPrice, now)
#                         if not cTrend and previoustrend: #(Current Trend = F and Previous Trend = T)
#                             # Exit
#                             for p in prepareData:
#                                 if p['stock'] == stockName:
#                                     if(p['boughtPrice'] <= avgPrice):
#                                         eq.writelog(stockName, cTrend, avgPrice, now)
                                        
#         index = index + 1
#         time.sleep(60)