from kite_trade import *
import threading
import time
import datetime
import winsound
import os

# # Second way is provide 'enctoken' manually from 'kite.zerodha.com' website
# # Than you can use login window of 'kite.zerodha.com' website Just don't logout from that window
# currStk = next((item for item in stocks if item['stock'] == stockName), None)
enctoken = "IF6JhdJLR4A2LTc+41M8FTbdHScBQbjv16QtC74JQDCyi4IzwDIdxcUuiSMDSnfEuLgbUIpLRmxraxDVPobfO71IFDhV9GlZO5Tuzi8wgEra89II+Og23Q=="
kite = KiteApp(enctoken=enctoken)

# Set Every Day
_timeframe = "15minute"
_exchange = "NSE"
_fileName = "report_27Sep.txt"
_watchList = ["SCHNEIDER"]
_fixedQty = 1
_previousTrend = False

_myPortFolio = []
_currentStockInfo = {
    "symbol": "",
    "token": "",
    "stopLossPrice": 0,
    "currentTrend": False,
    "avgPrice": 0,
    "openPrice": 0,
    "isExists": False,
    "isAllSet": False,
    "availablequantity": 0,
    "availableFund": 0
}
class Equity:
    def currentPostions(self):        
        positions = kite.orders() 
        for position in positions:           
            if(position['status'] == 'COMPLETE'):                                                        
                _myPortFolio.append({ "symbol" : position['tradingsymbol'], "token": position['instrument_token'], "quantity": position['quantity']})
    
    def currentHoldings(self):           
        holdings = kite.holdings()
        print("holdings")
        print(holdings)
        for holding in holdings: 
            qty = holding['quantity']
            currStk = next((item for item in _myPortFolio if item['symbol'] == holding["tradingsymbol"]), None)                         
            if currStk is not None:
                qty = currStk["quantity"] + holding['quantity']
            _myPortFolio.append({"symbol" : holding['tradingsymbol'], "token": holding['instrument_token'], "quantity": qty})
    
    def currentFund(self):                   
        _currentStockInfo["availableFund"] = kite.margins().get('equity').get('available').get("live_balance")    
        # print(kite.margins())

    def setInstrumentToken(self, symbol):
        instrument_token = kite.instruments(_exchange, symbol) 
        _currentStockInfo["token"] = instrument_token[0]["instrument_token"]
        _currentStockInfo["symbol"] = symbol
    
    def checkStockExists(self):                        
        currStk = next((item for item in _myPortFolio if item['symbol'] == _currentStockInfo["symbol"]), None)
        print("currStk")
        print(currStk)
        if currStk is not None:
            _currentStockInfo["availablequantity"] = currStk["quantity"]
            _currentStockInfo["isExists"] = True
        else:
            _currentStockInfo["isExists"] = False

    def setCurrentStockInfo(self):        
        from_datetime = datetime.datetime.now() - datetime.timedelta(days=5)     # From last & days
        to_datetime = datetime.datetime.now()        
        data = kite.historical_data(_currentStockInfo["token"], from_datetime, to_datetime, _timeframe, continuous=False, oi=False)                    
        _currentStockInfo["avgPrice"] = (data["open"].iloc[-1] + data["high"].iloc[-1] + data["low"].iloc[-1] + data["close"].iloc[-1]) / 4 
        _currentStockInfo["openPrice"] = data["open"].iloc[-1]
        sT = kite.Supertrend(data, 1, 2)
        _currentStockInfo["stopLossPrice"] = sT["Final Lowerband"].iloc[-1] 
        _currentStockInfo["currentTrend"] = sT["Supertrend"].iloc[-1]          
        _currentStockInfo["isAllSet"] = True
        return sT
    
    def writelog(self, stockName, trend, avgPrice, now):
         with open(_fileName, "a") as myfile:            
            orderType = "BUY" if trend else "SELL"
            myfile.write("\n")
            myfile.write(now.strftime("%Y-%m-%d %I:%M %p") + "\t" + str(stockName) + "\t" + str(orderType) +"\t" + str(avgPrice))
            myfile.close()
    
    def placeBuyOrder(self, contractName, stopLoss):
        order = kite.place_order(variety=kite.VARIETY_REGULAR,
                            exchange=kite.EXCHANGE_NSE,
                            tradingsymbol=contractName,
                            transaction_type=kite.TRANSACTION_TYPE_BUY,
                            quantity=_fixedQty,
                            product=kite.PRODUCT_MIS,
                            order_type=kite.ORDER_TYPE_MARKET,
                            price=None,
                            validity=None,
                            disclosed_quantity=None,
                            trigger_price=None,
                            squareoff=None, 
                            stoploss=stopLoss,
                            trailing_stoploss=None,
                            tag = "SuperTrendAlgo"
                            )
        return order
    def placeSellOrder(self, contractName, qty):
        order = kite.place_order(variety=kite.VARIETY_REGULAR,
                            exchange=kite.EXCHANGE_NSE,
                            tradingsymbol=contractName,
                            transaction_type=kite.TRANSACTION_TYPE_SELL,
                            quantity=qty,
                            product=kite.PRODUCT_MIS,
                            order_type=kite.ORDER_TYPE_MARKET,
                            price=None,
                            validity=None,
                            disclosed_quantity=None,
                            trigger_price=None,
                            squareoff=None, 
                            stoploss=None,
                            trailing_stoploss=None,
                            tag = "SuperTrendAlgo"
                            )
        return order
    def setPortFolio(self, symbol):
        self.currentPostions()
        self.currentHoldings()
        self.currentFund()
        self.setInstrumentToken(symbol)
        self.setCurrentStockInfo()  
        self.checkStockExists() 

    def isCurrentTimeDivisableBy5(self):
        myobj = datetime.datetime.now()
        if(myobj.minute % 5 == 0):
            return True
        else:
            return False

# Equity
if __name__ == '__main__':
    try:
        while True:
            now = datetime.datetime.today()        
            for stockName in _watchList:
                eq = Equity()             
                eq.setPortFolio(stockName)               
                print(now.strftime("%Y-%m-%d %I:%M %p"))                   
                print("Current Trend : " + str(_currentStockInfo["currentTrend"]))
                print("Stock Name : " + str(stockName))
                print(_currentStockInfo)                                  
                if _currentStockInfo["currentTrend"] != _previousTrend:
                    if _currentStockInfo["currentTrend"]:
                        print("Trend Changed to UP")
                        if(_currentStockInfo["availableFund"] > (_currentStockInfo["avgPrice"] * _fixedQty)):   
                            if not _currentStockInfo["isExists"]:
                                duration = 1000  # milliseconds
                                freq = 440  # Hz
                                winsound.Beep(freq, duration)                 
                                print("Buy Order placed to sent to exchange.. Average Price: " + str(_currentStockInfo["avgPrice"]))
                                _previousTrend = False if _currentStockInfo["currentTrend"] else True
                                # order = eq.placeBuyOrder(stockName, _currentStockInfo["stopLossPrice"]) 
                                # print(order)
                                # if order["status"].tolower() == "success":
                                #     print("CE Buy Order completed Successfully.. Order ID:", order)
                                # else:
                                #     print("CE Buy Order Failed.. Order ID:", order)
                                # eq.writelog(stockName, _currentStockInfo["currentTrend"], _currentStockInfo["avgPrice"], now)
                            else:
                                print("Position Already Exists")
                        else:
                            print("Insufficient Fund to Buy")
                    if not _currentStockInfo["currentTrend"]:
                        print("Trend Changed to DOWN")
                        if(_currentStockInfo["availableFund"] > (_currentStockInfo["avgPrice"] * _fixedQty)): 



                if _currentStockInfo["isExists"]:
                    if eq.isCurrentTimeDivisableBy5():
                        print("Sell Order placed to sent to exchange.. Average Price: " + str(_currentStockInfo["avgPrice"]))
                        # order = eq.placeSellOrder(stockName, _currentStockInfo["availablequantity"])
                        # print("order")
                        # print(order)
                        # if order["status"].tolower() == "success":
                        #     print("CE Buy Order completed Successfully.. Order ID:", order)
                        # else:
                        #     print("CE Buy Order Failed.. Order ID:", order)
                        eq.writelog(stockName, _currentStockInfo["currentTrend"], _currentStockInfo["avgPrice"], now)  
            print("---------------------------------------------------------------------------------\n")
            time.sleep(60)
    except Exception:
        duration = 1000  # milliseconds
        freq = 440  # Hz
        winsound.Beep(freq, duration)
    finally:
        duration = 1000  # milliseconds
        freq = 440  # Hz
        winsound.Beep(freq, duration)
        print("Press Enter to continue ...")
# portFolio = MyPortFolio()
# p = portFolio.PortFolio()
# print(p)
# e = Equity()
# i = e.getInstrumentToken("NSE", "RELIANCE")
# print(e.getCurrentLowerBandPrice("15minute", i))


