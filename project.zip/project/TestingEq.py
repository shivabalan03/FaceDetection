from kite_trade import *
import threading
import time
import datetime
import winsound
import os

# # Second way is provide 'enctoken' manually from 'kite.zerodha.com' website
# # Than you can use login window of 'kite.zerodha.com' website Just don't logout from that window
# currStk = next((item for item in stocks if item['stock'] == stockName), None)
enctoken = "IF5kAH6TmuXyJ9q4zAKMnJZP1lDPPMkliA3tNXOs61Rec7ZllRknKXxb3tXp98WHwqCF6DIMFJVh7ethWZEpcKzAzUhNvkuYCHB8G4ExFkluLKbuLccqDw=="
kite = KiteApp(enctoken=enctoken)

# Set Every Day
_timeframe = "15minute"
_exchange = "NSE"
_fileName = "report_27Sep.txt"
_watchList = ["HONAUT"]
_fixedQty = 10

_myPortFolio = []
_currentStockInfo = {
    "symbol": "",
    "token": "",
    "stopLossPrice": 0,
    "currentTrend": False,
    "avgPrice": 0,
    "openPrice": 0,
    "isExists": False,
    "isAllSet": False,
    "availablequantity": 0,
    "availableFund": 0
}
class Equity:
    def currentPostions(self):        
        positions = kite.orders() 
        for position in positions:           
            if(position['status'] == 'COMPLETE'):                                                        
                _myPortFolio.append({ "symbol" : position['tradingsymbol'], "token": position['instrument_token'], "quantity": position['quantity']})
    
    def currentHoldings(self):           
        holdings = kite.holdings()
        for holding in holdings: 
            qty = holding['quantity']
            currStk = next((item for item in _myPortFolio if item['symbol'] == holding["tradingsymbol"]), None)                         
            if currStk is not None:
                qty = currStk["quantity"] + holding['quantity']
            _myPortFolio.append({"symbol" : holding['tradingsymbol'], "token": holding['instrument_token'], "quantity": qty})
    
    def currentFund(self):                   
        _currentStockInfo["availableFund"] = kite.margins().get('equity').get('available').get("live_balance")    
        # print(kite.margins())

    def setInstrumentToken(self, symbol):
        instrument_token = kite.instruments(_exchange, symbol) 
        _currentStockInfo["token"] = instrument_token[0]["instrument_token"]
        _currentStockInfo["symbol"] = symbol
    
    def checkStockExists(self):                        
        currStk = next((item for item in _myPortFolio if item['symbol'] == _currentStockInfo["symbol"]), None)
        if currStk is not None:
            _currentStockInfo["availablequantity"] = currStk["quantity"]
            _currentStockInfo["isExists"] = True
        else:
            _currentStockInfo["isExists"] = False

    def setCurrentStockInfo(self):    
        today = datetime.datetime.today()    
        yesterday = today - datetime.timedelta(days=1)   
        from_datetime = yesterday - datetime.timedelta(days=5)     # From last & days
        to_datetime = yesterday       
        data = kite.historical_data(_currentStockInfo["token"], from_datetime, to_datetime, _timeframe, continuous=False, oi=False)                    
        _currentStockInfo["avgPrice"] = (data["open"].iloc[-1] + data["high"].iloc[-1] + data["low"].iloc[-1] + data["close"].iloc[-1]) / 4 
        _currentStockInfo["openPrice"] = data["open"].iloc[-1]
        sT = kite.Supertrend(data, 1, 2)
        _currentStockInfo["stopLossPrice"] = sT["Final Lowerband"].iloc[-1] 
        _currentStockInfo["currentTrend"] = sT["Supertrend"].iloc[-1]          
        _currentStockInfo["isAllSet"] = True
        return sT
    
    def writelog(self, stockName, trend, avgPrice, now):
         with open(_fileName, "a") as myfile:            
            orderType = "BUY" if trend else "SELL"
            myfile.write("\n")
            myfile.write(now.strftime("%Y-%m-%d %I:%M %p") + "\t" + str(stockName) + "\t" + str(orderType) +"\t" + str(avgPrice))
            myfile.close()
    
    def placeBuyOrder(self, contractName, stopLoss):
        order = kite.place_order(variety=kite.VARIETY_REGULAR,
                            exchange=kite.EXCHANGE_NSE,
                            tradingsymbol=contractName,
                            transaction_type=kite.TRANSACTION_TYPE_BUY,
                            quantity=_fixedQty,
                            product=kite.PRODUCT_CNC,
                            order_type=kite.ORDER_TYPE_MARKET,
                            price=None,
                            validity=None,
                            disclosed_quantity=None,
                            trigger_price=None,
                            squareoff=None, 
                            stoploss=stopLoss,
                            trailing_stoploss=None,
                            tag = "SuperTrendAlgo"
                            )
        return order
    def placeSellOrder(self, contractName, qty):
        order = kite.place_order(variety=kite.VARIETY_REGULAR,
                            exchange=kite.EXCHANGE_NSE,
                            tradingsymbol=contractName,
                            transaction_type=kite.TRANSACTION_TYPE_SELL,
                            quantity=qty,
                            product=kite.PRODUCT_CNC,
                            order_type=kite.ORDER_TYPE_MARKET,
                            price=None,
                            validity=None,
                            disclosed_quantity=None,
                            trigger_price=None,
                            squareoff=None, 
                            stoploss=None,
                            trailing_stoploss=None,
                            tag = "SuperTrendAlgo"
                            )
        return order
    def setPortFolio(self, symbol):
        self.currentPostions()
        self.currentHoldings()
        self.currentFund()
        self.setInstrumentToken(symbol)
        self.setCurrentStockInfo()  
        self.checkStockExists()  

# Equity
def mainMethod(self):
    if __name__ == '__main__':
        try:
            while True:
                now = datetime.datetime.today()        
                for stockName in _watchList:
                    eq = Equity()             
                    eq.setPortFolio(stockName)               
                    print(now.strftime("%Y-%m-%d %I:%M %p"))                   
                    print(_currentStockInfo)                                  
                    if _currentStockInfo["currentTrend"]:                
                        if not _currentStockInfo["isExists"]:  
                            if(_currentStockInfo["availableFund"] > (_currentStockInfo["avgPrice"] * _fixedQty)):                    
                                # order = eq.placeOrder(stockName, _currentStockInfo["stopLossPrice"]) 
                                print("CE Buy Order placed to sent to exchange.. Open Price: " + str(_currentStockInfo["openPrice"]))
                                # if order["status"].tolower() == "success":
                                #     print("CE Buy Order completed Successfully.. Order ID:", order)
                                # else:
                                #     print("CE Buy Order Failed.. Order ID:", order)
                                eq.writelog(stockName, _currentStockInfo["currentTrend"], _currentStockInfo["avgPrice"], now)
                            else:
                                print("Insufficient Fund to Buy")
                        else:
                            print("Position Already Exists") 
                    else:
                        if _currentStockInfo["isExists"]:
                            # order = eq.placeSellOrder(stockName, _currentStockInfo["availablequantity"])
                            eq.writelog(stockName, _currentStockInfo["currentTrend"], _currentStockInfo["avgPrice"], now)                                                     
                        else:
                            print("No Position to Sell")
                print("---------------------------------------------------------------------------------")
                time.sleep(60)
        except Exception:
            duration = 1000  # milliseconds
            freq = 440  # Hz
            winsound.Beep(freq, duration)
        finally:
            duration = 1000  # milliseconds
            freq = 440  # Hz
            winsound.Beep(freq, duration)
            print("Press Enter to continue ...")


class BackTesting:
    def printSuperTrend(self, symbol):
        instrument_token = kite.instruments(_exchange, symbol) 
        token = instrument_token[0]["instrument_token"]
        today = datetime.datetime.today()    
        yesterday = today - datetime.timedelta(days=1)   
        from_datetime = yesterday - datetime.timedelta(days=5) 
        to_datetime = yesterday       
        data = kite.historical_data(token, from_datetime, to_datetime, _timeframe, continuous=False, oi=False)                   
        sT = kite.Supertrend(data, 1, 2)
        print(sT)


eq = BackTesting()
eq.printSuperTrend("SCHNEIDER")



