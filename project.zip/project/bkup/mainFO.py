from kite_trade import *
import threading
import time
import datetime
import winsound
from pathlib import Path


# # Second way is provide 'enctoken' manually from 'kite.zerodha.com' website
# # Than you can use login window of 'kite.zerodha.com' website Just don't logout from that window
enctoken = "oUe0OOR++0samP/It0DnJKkC027/UOyWolFpeexV6hVwHZ/XqAbt4FlSnNys6FRWv770rnb4sWaPqVEcxopPmYypw2R0MXpJg17BDjTMsDlwGAzbtPFh5g=="
kite = KiteApp(enctoken=enctoken)

class MyPortFolio:
    def myPositions(self):
        currentPosition = []
        positions = kite.orders() 
        for position in positions:
            if(position['status'] == 'COMPLETE'):                        
                currentPosition.append({ "symbol" : position['tradingsymbol'], "token": position['instrument_token'], "quantity": position['quantity']})                

    def checkContractExists(self, contractName):        
        positions = kite.orders()         
        for position in positions:
            if(position['symbol'] == contractName):
                return True                
        return False
    
    def fundInfo(self):
        return kite.margins()

class CommonMethod():
    def getInstrumentToken(self, exchange, symbol):
        instrument_token = kite.instruments(exchange, symbol) 
        return instrument_token[0]["instrument_token"]

    def getCurrentAvgPrice(self, timeFrame, instrumentToken):   
        from_datetime = datetime.datetime.now() - datetime.timedelta(days=1) 
        to_datetime = datetime.datetime.now()        
        Hdata = kite.historical_data(instrumentToken, from_datetime, to_datetime, timeFrame, continuous=False, oi=False)        
        avg = (Hdata["open"].iloc[-1] + Hdata["high"].iloc[-1] + Hdata["low"].iloc[-1] + Hdata["close"].iloc[-1]) / 4        
        return avg
    
    def getCurrentTrend(self, timeFrame, instrumentToken):
        if instrumentToken != "":
            from_datetime = datetime.datetime.now() - datetime.timedelta(days=1)
            to_datetime = datetime.datetime.now()            
            self.data = kite.historical_data(instrumentToken, from_datetime, to_datetime, timeFrame, continuous=False, oi=False)    
            sTrend = kite.Supertrend(self.data, 1, 2)
            print(sTrend)
            currentTrend = sTrend["Supertrend"].iloc[-1]
            return currentTrend
        else:
            return "No Instrument Token Found"
        
    def writelog(self, stockName, trend, avgPrice, now):
         with open("report_26Sep.txt", "a") as myfile:            
            orderType = "BUY" if trend else "SELL"
            myfile.write("\n")
            myfile.write(now.strftime("%Y-%m-%d %I:%M %p") + "\t" + str(stockName) + "\t" + str(orderType) +"\t" + str(avgPrice))
            myfile.close()


timeFrame = "5minute"
optionContractDate = "NIFTY24OCT"
previousFlag = False
lotQty = 25 
if __name__ == '__main__':    
    while True:
        now = datetime.datetime.today()
        # duration = 1000  # milliseconds
        # freq = 440  # Hz
        # winsound.Beep(freq, duration)
        print("Started Main Job " + str(now))
        mine = MyPortFolio()
        commonMethod = CommonMethod()
        currentBalance = mine.fundInfo().get('equity').get('available').get("live_balance") 

        nifty50instrumentToken = commonMethod.getInstrumentToken("NSE", "NIFTY 50")
        nifty50AvgPrice = commonMethod.getCurrentAvgPrice(timeFrame, nifty50instrumentToken)
        currentTrend = commonMethod.getCurrentTrend(timeFrame, nifty50instrumentToken)
        nifty50StrikePrice = round(nifty50AvgPrice / 50) * 50  

        contractName = str(optionContractDate) + str(nifty50StrikePrice) + "CE"
        contractinstrumentToken = commonMethod.getInstrumentToken("NFO", contractName)
        contractPremium = round(commonMethod.getCurrentAvgPrice(timeFrame, contractinstrumentToken))        
        requiredMargin = lotQty * contractPremium 

        contractExists = mine.checkContractExists(contractName)                               
        if currentTrend:            
            if not contractExists:
                if(currentBalance > requiredMargin):
                    # order = kite.place_order(variety=kite.VARIETY_REGULAR,
                    #         exchange=kite.EXCHANGE_NFO,
                    #         tradingsymbol=contractName,
                    #         transaction_type=kite.TRANSACTION_TYPE_BUY,
                    #         quantity=lotQty,
                    #         product=kite.PRODUCT_NRML,
                    #         order_type=kite.ORDER_TYPE_MARKET,
                    #         price=None,
                    #         validity=None,
                    #         disclosed_quantity=None,
                    #         trigger_price=None,
                    #         squareoff=None, 
                    #         stoploss=None,
                    #         trailing_stoploss=None,
                    #         tag = "SuperTrendAlgo"
                    #         )
                    print("CE Buy Order Placed Successfully.. Order ID:", order)
                    commonMethod.writelog(contractName, "BUY", contractPremium, now)
                else:
                    print("Not Enough Balance")
            else:
                print("Position Already Exists")
        else:
            if contractExists:
                # order = kite.place_order(variety=kite.VARIETY_REGULAR,
                #             exchange=kite.EXCHANGE_NFO,
                #             tradingsymbol=contractName,
                #             transaction_type=kite.TRANSACTION_TYPE_SELL,
                #             quantity=lotQty,
                #             product=kite.PRODUCT_NRML,
                #             order_type=kite.ORDER_TYPE_MARKET,
                #             price=None,
                #             validity=None,
                #             disclosed_quantity=None,
                #             trigger_price=None,
                #             squareoff=None, 
                #             stoploss=None,
                #             trailing_stoploss=None,
                #             tag = "SuperTrendAlgo"
                #             )
                commonMethod.writelog(contractName, "SELL", contractPremium, now)
            else:
                print("Position Not Exists")
        time.sleep(60) # 60=1min 120=2min 300=5min 600=10min 900=15min 1800=30min 3600=1hr 7200=2hr 14400=4hr 28800=8hr 43200=12hr 86400=1day

# Step 1: 
#Loop Every 5 Minutes
    # InstrumentToken then HistoryData then SuperTrend
    # If Previous Trend Value != Current Trend Value
        # If Previous Trend Value == True and Current Trend Value == False            
            # Prepare OptionContract Instrument eg (NIFTY24OCT25900CE)
            # Check available postion qty and Exit Order with available qty
        # Else if Previous Trend Value == false and Current Trend Value == true
            # Calculate Avg and nifty 50 Find nearest value by 50 and Prepare OptionContract Instrument eg (NIFTY24OCT25900CE)
            # Get Live balance
            # check margin by given position qty
            # if(enough balance) then Buy