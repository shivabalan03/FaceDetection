from kite_trade import *
import threading
import time
import datetime
import winsound
import os
import json
from flask import *
app = Flask(__name__)

# # Second way is provide 'enctoken' manually from 'kite.zerodha.com' website
# # Than you can use login window of 'kite.zerodha.com' website Just don't logout from that window
# currStk = next((item for item in stocks if item['stock'] == stockName), None)
enctoken = "nZefOaxCLz4lq3/VG4hghqJLERVQvv3EuvbeRKgYpNEPK59KxiaPRDzFm0Vg6gjO25U7rzddaIZqZ6AlX+NkGh+qTwwg8pl50GRfwUTwtQ8qUXHeXvM2jA=="
kite = KiteApp(enctoken=enctoken)
kiteNew = ZerodhaKiteTrade()

data1 = {
    "stock": {
        "stockName": "LLOYDSME", # Need to Set
        "exchange": "NSE",
        "instrumentToken": "",
    },
    "common": {
        "dateTime": datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S %p"),
        "message": "",
        "transactionType": "",
        "availableFund": 0,
        "availableQuantity": 0,
        "plannedQuantity": 10, # Need to Set
    },
    "trendInfo": {
        "o": 0,
        "h": 0,
        "l": 0,
        "c": 0,
        "a": 0,
        "recentT": [],
        "previousT": "",
        "currentT": "",
    }
}

class Equity:
    def placeOrder(self, transactionType, additionalQty=0):
        if data1["common"]["availableQuantity"] == 0 or data1["common"]["availableQuantity"] == -(data1["common"]["plannedQuantity"]) or data1["common"]["availableQuantity"] == (data1["common"]["plannedQuantity"]):
            order = kite.place_order(variety=kite.VARIETY_REGULAR,
                                exchange=kite.EXCHANGE_NSE,
                                tradingsymbol=data1["stock"]["stockName"],
                                transaction_type=transactionType,#kite.TRANSACTION_TYPE_BUY,
                                quantity=(data1["common"]["plannedQuantity"] + additionalQty),
                                product=kite.PRODUCT_MIS,
                                order_type=kite.ORDER_TYPE_MARKET,
                                price=None,
                                validity=None,
                                disclosed_quantity=None,
                                trigger_price=None,
                                squareoff=None, 
                                stoploss=None,
                                trailing_stoploss=None,
                                tag = "SuperTrendAlgo"
                                )            
            self.currentPostions()
            return order
        else:
            data1["common"]["message"] = "Quantity limit has been Reached Please check"
            return None
    def currentFund(self):                   
        data1["common"]["availableFund"] = kite.margins().get('equity').get('available').get("live_balance") 
    def currentPostions(self):        
        positions = kite.positions()  
        if positions is not None:       
            currStk = next((item for item in positions['day'] if item['tradingsymbol'] == data1["stock"]["stockName"] and item['exchange'] == data1["stock"]["exchange"] and item['product'] == 'MIS'), None)
            if currStk is not None:
                data1["common"]["availableQuantity"] = currStk['quantity'] 
    def setInstrumentToken(self):  
        instrument_token = kite.instruments(data1["stock"]["exchange"], data1["stock"]["stockName"])         
        data1["stock"]["instrumentToken"] = instrument_token[0]["instrument_token"]      
        from_datetime = datetime.datetime.now() - datetime.timedelta(days=5)     # From last & days
        to_datetime = datetime.datetime.now()             
        history = kite.historical_data(data1["stock"]["instrumentToken"], from_datetime, to_datetime, "5minute", continuous=False, oi=False)                                          
        data1["trendInfo"]["a"] = (history["open"].iloc[-1] + history["high"].iloc[-1] + history["low"].iloc[-1] + history["close"].iloc[-1]) / 4         
        data1["trendInfo"]["o"] = history["open"].iloc[-1]                        
        data1["trendInfo"]["h"] = history["high"].iloc[-1] 
        data1["trendInfo"]["l"] = history["low"].iloc[-1]                
        data1["trendInfo"]["c"] = history["close"].iloc[-1]  
        # trendInfo = kite.Supertrend(history, 10, 3)  
        trendInfo = kiteNew.SuperTrend(history, 10, 3)
        data1["trendInfo"]["currentT"] = trendInfo["STX"].iloc[-1] 
        if len(data1["trendInfo"]["recentT"]) >= 3:
            data1["trendInfo"]["recentT"].pop(0)
            data1["trendInfo"]["recentT"].append(data1["trendInfo"]["currentT"])
        else:
            data1["trendInfo"]["recentT"].append(data1["trendInfo"]["currentT"])
    def setAllData(self):
        self.currentFund() 
        self.currentPostions()
        self.setInstrumentToken()

@app.route('/')
def index():
    return render_template('Equity1.html')

@app.route('/getDataEQ1', methods=['POST'])
def mainMethod():    
    # qtc_data = request.get_json()    
    equity = Equity()
    try:                        
        equity.setAllData() 
        data1["common"]["dateTime"] = datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S %p")
        data1["common"]["message"] = ""
        data1["common"]["transactionType"] = ""
        if (len(data1["trendInfo"]["recentT"]) < 3):
            data1["common"]["message"] = "Current Trend length < 3"
        else:
            if (len(data1["trendInfo"]["recentT"]) == 3):                
                if ((data1["trendInfo"]["recentT"][0]  == data1["trendInfo"]["recentT"][1]  == data1["trendInfo"]["recentT"][2]) and 
                    (data1["trendInfo"]["previousT"] != data1["trendInfo"]["recentT"][0]) or data1["trendInfo"]["previousT"] == ""):  
                        if data1["common"]["availableQuantity"] == 0:
                            if data1["trendInfo"]["currentT"]:                                
                                o = equity.placeOrder(kite.TRANSACTION_TYPE_BUY)
                                print(o)
                                data1["trendInfo"]["previousT"] = data1["trendInfo"]["currentT"]
                                data1["common"]["message"] = "Buy Order Placed"
                                data1["common"]["transactionType"] = "BUY"
                                print(data1["common"]["message"])
                            else:
                                o = equity.placeOrder(kite.TRANSACTION_TYPE_SELL)
                                print(o)
                                data1["trendInfo"]["previousT"] = data1["trendInfo"]["currentT"]
                                data1["common"]["message"] = "Sell Order Placed"
                                data1["common"]["transactionType"] = "SELL"
                                print(data1["common"]["message"])
                        else:
                            if data1["common"]["availableQuantity"] == -(data1["common"]["plannedQuantity"]):
                                if data1["trendInfo"]["recentT"][0] and data1["trendInfo"]["recentT"][1] and data1["trendInfo"]["recentT"][2]:                                
                                    o = equity.placeOrder(kite.TRANSACTION_TYPE_BUY, data1["common"]["plannedQuantity"])
                                    print(o)
                                    data1["trendInfo"]["previousT"] = data1["trendInfo"]["currentT"]
                                    data1["common"]["message"] = "Buy Order Placed"
                                    data1["common"]["transactionType"] = "BUY"
                                    print(data1["common"]["message"])
                            elif data1["common"]["availableQuantity"] == data1["common"]["plannedQuantity"]:
                                if not data1["trendInfo"]["recentT"][0] and not data1["trendInfo"]["recentT"][1] and not data1["trendInfo"]["recentT"][2]:
                                    o = equity.placeOrder(kite.TRANSACTION_TYPE_SELL, data1["common"]["plannedQuantity"])
                                    print(o)
                                    data1["trendInfo"]["previousT"] = data1["trendInfo"]["currentT"]
                                    data1["common"]["message"] = "Sell Order Placed"
                                    data1["common"]["transactionType"] = "SELL"
                                    print(data1["common"]["message"])
                else:
                    data1["common"]["message"] = "No Trend Reversal"
                    print("No Trend Change")
    except Exception as inst:
        print(type(inst))    # the exception type
        print(inst.args)     # arguments stored in .args
        print(inst)          # __str__ allows args to be printed directly,
                            # but may be overridden in exception subclasses
        x, y = inst.args     # unpack args
        print('x =', x)
        print('y =', y)
    finally:        
        print("Press Enter to continue ...")
        print(data1)
        return json.dumps(data1, default=str) # json.dumps({"data":obj})

if __name__ == '__main__':    
    app.run(debug=True, port=5001)