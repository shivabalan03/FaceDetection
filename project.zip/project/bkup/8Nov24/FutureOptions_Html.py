from kite_trade import *
import threading
import time
import datetime
import winsound
from pathlib import Path
from flask import *
app = Flask(__name__)


# # Second way is provide 'enctoken' manually from 'kite.zerodha.com' website
# # Than you can use login window of 'kite.zerodha.com' website Just don't logout from that window
enctoken = "K5cR51+CkTSymHp35P9rX/b1buDWKIvTJI/hGkIWBALxlIEbXgWQFm4hsIoaM/ewYMRtRcrRa6ogvGCHml1TKttKy15DCeQ4i5IBWTxR5CzBf9l7i4WAvA=="
kite = KiteApp(enctoken=enctoken)

# Set Every Day
_timeFrame = "5minute"
_optionContractDate = "NIFTY24OCT"
_lotQty = 25 
_EquityExchange = "NSE"
_FandOExchange = "NFO"
_nifty50Symbol = "NIFTY 50"

# Variables and Information
_currentFund = 0
_isPositionExists = True
_currentContractInfo = {
    "contractName": "",
    "stopLoss": 0,
    "token": "",
    "avgPrice": 0,
    "positionExists": True,
    "contractPremium": 0,
    "requiredMargin": 0,
    "availablequantity": 0
}
_nifty50Info = {
    "token": "",
    "avgPrice": 0,
    "currentTrend": False,
    "strikePrice": 0,
    "availableFund": 0
}

_completeData = []
class FandO:
    def writelog(self, stockName, trend, avgPrice, now):
         with open("report_30Sep.txt", "a") as myfile:            
            orderType = "BUY" if trend else "SELL"
            myfile.write("\n")
            myfile.write(now.strftime("%Y-%m-%d %I:%M %p") + "\t" + str(stockName) + "\t" + str(orderType) +"\t" + str(avgPrice))
            myfile.close()

    def fundInfo(self):
        _nifty50Info["availableFund"] = kite.margins().get('equity').get('available').get("live_balance")        
        
    
    def setNifty50InstrumentToken(self):
        instrument_token = kite.instruments(_EquityExchange, _nifty50Symbol) 
        _nifty50Info["token"] = instrument_token[0]["instrument_token"]
        _currentContractInfo["symbol"] = _nifty50Symbol

    def setContractInstrumentToken(self):
        instrument_token = kite.instruments(_FandOExchange, _currentContractInfo["contractName"]) 
        _currentContractInfo["token"] = instrument_token[0]["instrument_token"]

    def setNifty50Info(self):
        from_datetime = datetime.datetime.now() - datetime.timedelta(days=1) 
        to_datetime = datetime.datetime.now()    
        Hdata = kite.historical_data(_nifty50Info["token"], from_datetime, to_datetime, _timeFrame, continuous=False, oi=False) 
        _nifty50Info["avgPrice"] = (Hdata["open"].iloc[-1] + Hdata["high"].iloc[-1] + Hdata["low"].iloc[-1] + Hdata["close"].iloc[-1]) / 4        
        sTrend = kite.Supertrend(Hdata, 1, 2)
        _nifty50Info["currentTrend"] = sTrend["Supertrend"].iloc[-1]
        _nifty50Info["strikePrice"] = round(_nifty50Info["avgPrice"] / 50) * 50
        _currentContractInfo["contractName"] = str(_optionContractDate) + str(_nifty50Info["strikePrice"]) + "CE"
    
    def myPositionsQuantity(self):        
        positions = kite.positions()    
        isExists = 0    
        for position in positions["net"]:                       
            if position["exchange"] == "NFO" and position["quantity"] > 0:
                return position["quantity"]                      
        return isExists
    
    def setContractInfo(self):        
        from_datetime = datetime.datetime.now() - datetime.timedelta(days=1) 
        to_datetime = datetime.datetime.now()        
        Hdata = kite.historical_data(_currentContractInfo["token"], from_datetime, to_datetime, _timeFrame, continuous=False, oi=False)                
        sTrend = kite.Supertrend(Hdata, 1, 2)
        _currentContractInfo["stopLoss"] = sTrend["Final Lowerband"].iloc[-1] 
        _currentContractInfo["avgPrice"] = (sTrend["open"].iloc[-1] + sTrend["high"].iloc[-1] + sTrend["low"].iloc[-1] + sTrend["close"].iloc[-1]) / 4        
        _currentContractInfo["contractPremium"] = round(_currentContractInfo["avgPrice"])
        _currentContractInfo["positionExists"] = True if self.myPositionsQuantity() > 0 else False
        _currentContractInfo["requiredMargin"] = _currentContractInfo["avgPrice"] * _lotQty
        _currentContractInfo["availablequantity"] = self.myPositionsQuantity()
    
    def setNifty50andContractInfo(self):
        self.fundInfo()
        self.setNifty50InstrumentToken()
        self.setNifty50Info()

        self.setContractInstrumentToken()
        self.setContractInfo()


@app.route('/', methods=['GET'])
def renderIndex():
    return render_template('index.html', nifty50Info=_completeData, contractInfo=_currentContractInfo)

@app.route('/getData', methods=['GET'])
def mainMethod():     
        while True:
            now = datetime.datetime.today()
            # duration = 1000  # milliseconds
            # freq = 440  # Hz
            # winsound.Beep(freq, duration)
            print("Started Main Job " + str(now))
            fo = FandO()
            fo.setNifty50andContractInfo()
            print("Nifty50 Info: ", _nifty50Info)
            print("Contract Info: ", _currentContractInfo)
            if _nifty50Info["currentTrend"]:            
                if not _currentContractInfo["positionExists"]:
                    if(_nifty50Info["availableFund"] > _currentContractInfo["requiredMargin"]):
                        # order = kite.place_order(variety=kite.VARIETY_REGULAR,
                        #         exchange=kite.EXCHANGE_NFO,
                        #         tradingsymbol=_currentContractInfo["contractName"],
                        #         transaction_type=kite.TRANSACTION_TYPE_BUY,
                        #         quantity=_lotQty,
                        #         product=kite.PRODUCT_NRML,
                        #         order_type=kite.ORDER_TYPE_MARKET,
                        #         price=None,
                        #         validity=None,
                        #         disclosed_quantity=None,
                        #         trigger_price=None,
                        #         squareoff=None, 
                        #         stoploss=None,
                        #         trailing_stoploss=None,
                        #         tag = "SuperTrendAlgo"
                        #         )
                        print("CE Buy Order placed to sent to exchange.. Order ID:", order)
                        # if order["status"] == "success":
                        #     print("CE Buy Order completed Successfully.. Order ID:", order)
                        # else:
                        #     print("CE Buy Order Failed.. Order ID:", order)
                        fo.writelog(_currentContractInfo["contractName"], "BUY", _currentContractInfo["contractPremium"], now)
                    else:
                        print("Not Enough Balance")
                else:
                    print("Position Already Exists")
            else:
                if _currentContractInfo["positionExists"]:
                    # order = kite.place_order(variety=kite.VARIETY_REGULAR,
                    #             exchange=kite.EXCHANGE_NFO,
                    #             tradingsymbol=_currentContractInfo["contractName"],
                    #             transaction_type=kite.TRANSACTION_TYPE_SELL,
                    #             quantity=_currentContractInfo["availablequantity"],
                    #             product=kite.PRODUCT_NRML,
                    #             order_type=kite.ORDER_TYPE_MARKET,
                    #             price=None,
                    #             validity=None,
                    #             disclosed_quantity=None,
                    #             trigger_price=None,
                    #             squareoff=None, 
                    #             stoploss=None,
                    #             trailing_stoploss=None,
                    #             tag = "SuperTrendAlgo"
                    #             )
                    fo.writelog(_currentContractInfo["contractName"], "SELL", _currentContractInfo["contractPremium"], now)
                else:
                    print("Position Not Exists")

            _completeData.append(_nifty50Info)
            print('_completeData')
            print(_completeData)
            # return jsonify(_completeData)
            return current_app.json.response(_completeData)
            # time.sleep(60) # 60=1min 120=2min 300=5min 600=10min 900=15min 1800=30min 3600=1hr 7200=2hr 14400=4hr 28800=8hr 43200=12hr 86400=1day
if __name__ == '__main__':  
    app.run(debug=True)     

# Step 1: 
#Loop Every 5 Minutes
    # InstrumentToken then HistoryData then SuperTrend
    # If Previous Trend Value != Current Trend Value
        # If Previous Trend Value == True and Current Trend Value == False            
            # Prepare OptionContract Instrument eg (NIFTY24OCT25900CE)
            # Check available postion qty and Exit Order with available qty
        # Else if Previous Trend Value == false and Current Trend Value == true
            # Calculate Avg and nifty 50 Find nearest value by 50 and Prepare OptionContract Instrument eg (NIFTY24OCT25900CE)
            # Get Live balance
            # check margin by given position qty
            # if(enough balance) then Buy