# from ZerodhaKite_Trade import ZerodhaKiteTrade
from kite_trade import *
import threading
import time
import datetime
import nsepy as nse
from datetime import date, timedelta
from datetime import datetime, time
import winsound
import os

enctoken = "JbXSX9wlrHBp7e9chGLscdxx11AqQq/Tryu7FO7mMRjW2qE1DiGErpRWqK7abg1Zs+8q1FbRE2uM91nukAjMDQvvCItw7i3AnQZmyzrZXJ4Jwhmhn4NLSA=="
kite = KiteApp(enctoken=enctoken)
zerodhaKiteTrade = ZerodhaKiteTrade()
market = "NSE"
stock = "NIFTY 50"

class Equity:
    def currentOrders(self):        
        print(kite.orders())

    def currentHolding(self):        
        print(kite.holdings())   

    def currentPosition(self):        
        print(kite.positions())  

    def currentInstrument(self):        
        print(kite.instruments(market, stock))

    def setInstrumentToken(self):        
        instrument_token = kite.instruments(market, stock)                
        token = instrument_token[0]["instrument_token"]     
        from_datetime = datetime.datetime.now() - datetime.timedelta(days=5)     # From last & days
        to_datetime = datetime.datetime.now()
        data = kite.historical_data(token, from_datetime, to_datetime, "5minute", continuous=False, oi=False) 
        trendInfo = zerodhaKiteTrade.SuperTrend(data, 10, 3)
        # trendInfo = kite.Supertrend(data, 10, 3) 
        print(trendInfo)
        print(trendInfo["STX"].iloc[-1])      
 
    def get_nearest_strike_price(spot_price, strike_prices):
        """Gets the nearest strike price to the given spot price."""
        return min(strike_prices, key=lambda x: abs(x - spot_price))
    
    # # Get Nifty option chain data
    # nifty_opt = nse.get_history(symbol="NIFTY",
    #                             start=datetime.datetime.today(),
    #                             end=datetime.datetime.today(),
    #                             index=True,
    #                             option_type='CE', 
    #                             expiry_date=expiry_date)
    
    # # Extract strike prices
    # strike_prices = nifty_opt['Strike Price'].unique().tolist()    
    # # Get the current spot price of Nifty
    # nifty_spot = nse.get_index_quote("NIFTY 50")["lastPrice"]
    # # Find the nearest strike price
    # nearest_strike = get_nearest_strike_price(nifty_spot, strike_prices)    
    # print("Nearest strike price:", nearest_strike)

    # def ltp(self):        
    #     data = kite.ltp() 
    #     print(data)     

# eq = Equity()
# eq.currentInstrument()
# eq.currentOrders()
# print("------------------------------\n")
# eq.currentHolding()
# print("------------------------------\n")
# eq.currentPosition()
# print("------------------------------")
# eq.setInstrumentToken()
# eq.ltp()


print(datetime.now().time())
print(datetime.now().time() > time(15,00))  


