from kite_trade import *
import threading
import time
import datetime
import winsound
from pathlib import Path
import json
from flask import *
app = Flask(__name__)

# # Second way is provide 'enctoken' manually from 'kite.zerodha.com' website
# # Than you can use login window of 'kite.zerodha.com' website Just don't logout from that window
enctoken = "Z1jAvNoh+3jRsGRbJIsZ5ClDrDQ6RZmxmDEcJfu8xsGjuzgCNqESnen62mqQJrdg6i0p8w4KuOgT49YF836tKvAGdW8xfWBqCqhJcGlOQ6KrAQ7FZMXb+w=="
kite = KiteApp(enctoken=enctoken)
kiteNew = ZerodhaKiteTrade()

# Set Every Day
_timeFrame = "5minute"
_optionContractDate = "NIFTY24NOV"
_lotQty = 50
_EquityExchange = "NSE"
_FandOExchange = "NFO"
_indexSymbol = "NIFTY 50"

# Variables and Information
_currentFund = 0
_isPositionExists = True
obj = {}
_orderHistoryContract = ""
_currentContractInfo = {
    "calculatedContractName": "",
    "positionContractName": "",
    "stopLoss": 0,
    "token": "",
    "avgPrice": 0,
    "positionExists": True,
    "contractPremium": 0,
    "requiredMargin": 0,
    "availablequantity": 0,
    "OrderHistory": ""
}
_nifty50Info = {
    "token": "",
    "avgPrice": 0,
    "currentTrend": False,
    "strikePrice": 0,
    "availableFund": 0
}

class FandO:
    def orderHistorylog(self, type, contractName):
        if(type == "BUY"):
            with open("OrderHistory_NiftyPE.txt", "a") as myfile1:
                myfile1.write(contractName)
                myfile1.close()
        else:
             open('OrderHistory_NiftyPE.txt', 'w').close()

    def setOrderHistoryContractName(self):
        with open("OrderHistory_NiftyPE.txt", "r") as myfile:
            _currentContractInfo["OrderHistory"] = myfile.read()
            myfile.close()

    def fundInfo(self):
        _nifty50Info["availableFund"] = kite.margins().get('equity').get('available').get("live_balance")


    def setNifty50InstrumentToken(self):
        instrument_token = kite.instruments(_EquityExchange, _indexSymbol)
        _nifty50Info["token"] = instrument_token[0]["instrument_token"]
        _currentContractInfo["symbol"] = _indexSymbol

    def setContractInstrumentToken(self):
        instrument_token = kite.instruments(_FandOExchange, _currentContractInfo["calculatedContractName"])
        _currentContractInfo["token"] = instrument_token[0]["instrument_token"]

    def setNifty50Info(self):
        from_datetime = datetime.datetime.now() - datetime.timedelta(days=1)
        to_datetime = datetime.datetime.now()
        Hdata = kite.historical_data(_nifty50Info["token"], from_datetime, to_datetime, _timeFrame, continuous=False, oi=False)
        _nifty50Info["avgPrice"] = (Hdata["open"].iloc[-1] + Hdata["high"].iloc[-1] + Hdata["low"].iloc[-1] + Hdata["close"].iloc[-1]) / 4
        # sTrend = kite.Supertrend(Hdata, 10, 3)            
        sTrend = kiteNew.SuperTrend(Hdata, 10, 3)            
        _nifty50Info["currentTrend"] = sTrend["STX"].iloc[-1]
        # _nifty50Info["strikePrice"] = round(_nifty50Info["avgPrice"] / 50) * 50 //Bkup (26Nov'24)
        niftyLTPLastTwoDigits = _nifty50Info["avgPrice"] % 100
        _nifty50Info["strikePrice"] = round(_nifty50Info["avgPrice"] / 50) * 50
        if((niftyLTPLastTwoDigits > 25 and niftyLTPLastTwoDigits <= 50) or (niftyLTPLastTwoDigits >= 75 and niftyLTPLastTwoDigits <= 99)):
            _nifty50Info["strikePrice"] -= 50
        _currentContractInfo["calculatedContractName"] = str(_optionContractDate) + str(_nifty50Info["strikePrice"]) + "PE"

    def myPositionsQuantity(self):
        positions = kite.positions()
        isExists = 0
        for position in positions["net"]:
            if position["exchange"] == "NFO" and position["quantity"] > 0 and position["tradingsymbol"] == _currentContractInfo["OrderHistory"]:
                _currentContractInfo["positionContractName"] = position["tradingsymbol"]
                return position["quantity"]
        return isExists

    def setContractInfo(self):
        from_datetime = datetime.datetime.now() - datetime.timedelta(days=1)
        to_datetime = datetime.datetime.now()
        Hdata = kite.historical_data(_currentContractInfo["token"], from_datetime, to_datetime, _timeFrame, continuous=False, oi=False)
        # sTrend = kite.Supertrend(Hdata, 10, 3)
        sTrend = kiteNew.SuperTrend(Hdata, 10, 3)
        _currentContractInfo["stopLoss"] = sTrend["final_lb"].iloc[-1]
        _currentContractInfo["avgPrice"] = (sTrend["open"].iloc[-1] + sTrend["high"].iloc[-1] + sTrend["low"].iloc[-1] + sTrend["close"].iloc[-1]) / 4
        _currentContractInfo["contractPremium"] = round(_currentContractInfo["avgPrice"])
        _currentContractInfo["availablequantity"] = self.myPositionsQuantity()
        _currentContractInfo["requiredMargin"] = _currentContractInfo["avgPrice"] * _lotQty
        _currentContractInfo["positionExists"] = True if (_currentContractInfo["availablequantity"] > 0) else False

    def notification(self):
        duration = 1000  # milliseconds
        freq = 440  # Hz
        winsound.Beep(freq, duration)

    def setNifty50andContractInfo(self):
        self.fundInfo()
        self.setNifty50InstrumentToken()
        self.setNifty50Info()

        self.setOrderHistoryContractName()
        self.setContractInstrumentToken()
        self.setContractInfo()

@app.route('/')
def index():
    return render_template('Nifty_PEBuyExit.html')

@app.route('/getPEData', methods=['POST'])
def mainMethod():
    try:
        now = datetime.datetime.today()
        print("Started Main Job PE Algo " + str(_indexSymbol) + " - " + str(now))
        obj["Date"] = now.strftime("%Y-%m-%d %I:%M:%S %p")
        fo = FandO()
        fo.setNifty50andContractInfo()
        obj["_currentContractInfo"] = _currentContractInfo
        obj["_nifty50Info"] = _nifty50Info
        obj["_message"] = ""
        print("Nifty50 Info: ", _nifty50Info)
        print("Contract Info: ", _currentContractInfo)
        if not _nifty50Info["currentTrend"]:
            if not _currentContractInfo["positionExists"]:
                if(_nifty50Info["availableFund"] > _currentContractInfo["requiredMargin"]):
                    # order = kite.place_order(variety=kite.VARIETY_REGULAR,
                    #         exchange=kite.EXCHANGE_NFO,
                    #         tradingsymbol=_currentContractInfo["calculatedContractName"],
                    #         transaction_type=kite.TRANSACTION_TYPE_BUY,
                    #         quantity=_lotQty,
                    #         product=kite.PRODUCT_NRML,
                    #         order_type=kite.ORDER_TYPE_MARKET,
                    #         price=None,
                    #         validity=None,
                    #         disclosed_quantity=None,
                    #         trigger_price=None,
                    #         squareoff=None,
                    #         stoploss=None,
                    #         trailing_stoploss=None,
                    #         tag = "SuperTrendAlgo"
                    # )
                    order = {
                        "status": "success",
                        "data": {"order_id": "123456"},
                    }

                    print("PE Buy Order Sent to Exchange..")
                    if order["status"] == "success":
                        fo.orderHistorylog("BUY", _currentContractInfo["calculatedContractName"])
                        print (order)
                        print("Buy Completed Successfully..! \n Order Id :" + str(order["data"]["order_id"]) + " Contract Name:  " + str(_currentContractInfo["calculatedContractName"]))
                        obj["_message"] = "Buy Completed Successfully..! \n Order Id :" + str(order["data"]["order_id"]) + " Contract Name:  " + str(_currentContractInfo["calculatedContractName"])
                    else:
                        print("Order failed : " + str(order))
                        obj["_message"] = "Order failed " + str(order)
                    fo.notification()
                else:
                    print("Not Enough Balance")
                    obj["_message"] = "Not Enough Balance"
            else:
                print("Position Already Exists : " + str(_currentContractInfo["positionContractName"]) + " : " + str(_currentContractInfo["availablequantity"]))
                obj["_message"] = "Position Already Exists : " + str(_currentContractInfo["positionContractName"]) + " : " + str(_currentContractInfo["availablequantity"])
        else:
            if _currentContractInfo["positionExists"]:
                print(_currentContractInfo["positionContractName"])
                print(_orderHistoryContract)
                if _currentContractInfo["positionContractName"] == _currentContractInfo["OrderHistory"]:
                    if _currentContractInfo["positionContractName"] != "":
                        # order = kite.place_order(variety=kite.VARIETY_REGULAR,
                        #             exchange=kite.EXCHANGE_NFO,
                        #             tradingsymbol=_currentContractInfo["positionContractName"],
                        #             transaction_type=kite.TRANSACTION_TYPE_SELL,
                        #             quantity=_currentContractInfo["availablequantity"],
                        #             product=kite.PRODUCT_NRML,
                        #             order_type=kite.ORDER_TYPE_MARKET,
                        #             price=None,
                        #             validity=None,
                        #             disclosed_quantity=None,
                        #             trigger_price=None,
                        #             squareoff=None,
                        #             stoploss=None,
                        #             trailing_stoploss=None,
                        #             tag = "SuperTrendAlgo"
                        # )
                        order = {
                            "status": "success",
                            "data": {"order_id": "123456"},
                        }

                        print("PE EXIT Order Sent to Exchange..", _currentContractInfo["positionContractName"])
                        if order["status"] == "success":
                            fo.orderHistorylog("SELL", "")
                            print (order)
                            print("EXIT Completed Successfully..! \n Order Id :" + str(order["data"]["order_id"]) + " Contract Name:  " + str(_currentContractInfo["calculatedContractName"] + " Quantity: " + str(_currentContractInfo["availablequantity"])))
                            obj["_message"] = "EXIT Completed Successfully..! \n Order Id :" + str(order["data"]["order_id"]) + " Contract Name:  " + str(_currentContractInfo["calculatedContractName"] + " Quantity: " + str(_currentContractInfo["availablequantity"]))
                        else:
                            print("Order failed : " + order)
                            obj["_message"] = "Order failed"
                        fo.notification()
                    else:
                        print("Order History is Empty")
                        obj["_message"] = "Order History is Empty"
                else:
                    print("Position Not Entered by Algo : " + str(_currentContractInfo["positionContractName"]))
                    obj["_message"] = "Position Not Entered by Algo : " + str(_currentContractInfo["positionContractName"])
            else:
                print("Position does not exists")
                obj["_message"] = "Position does not exists"
        print("---------------------------------------------------------------------------------------------------------------\n\n")        
    except Exception as inst:
        print(type(inst))    # the exception type
        print(inst.args)     # arguments stored in .args
        print(inst)          # __str__ allows args to be printed directly,
                            # but may be overridden in exception subclasses
        x, y = inst.args     # unpack args
        print('x =', x)
        print('y =', y)
    finally:
        return json.dumps(obj, default=str)
        # time.sleep(60) # 60=1min 120=2min 300=5min 600=10min 900=15min 1800=30min 3600=1hr 7200=2hr 14400=4hr 28800=8hr 43200=12hr 86400=1day

if __name__ == '__main__':
    app.run(debug=True, port=5002)
# mainMethod()