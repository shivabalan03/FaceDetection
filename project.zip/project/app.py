from flask import *
# from main import findSuperTrend

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

# @app.route('/getData', methods=['GET'])
# def findData():
#     if request.method == 'GET':
#         # minute = request.form['time']
#         # token = request.form['token']
#         # print({'time': time, 'stock': stock})
#         # data = findSuperTrend(token, minute)
#         # print(data)
#         return "data"


if __name__ == '__main__':    
    app.run(debug=True, port=5001)